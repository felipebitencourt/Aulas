# Variáveis Globais
produtos = []
vendas = []
total_vendas = 0