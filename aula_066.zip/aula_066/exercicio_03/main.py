from funcoes import *

limpa()


resposta = ""
while(resposta.lower() != "sim"): resposta = input("Você passou no teste? ")

print("\nParabéns!")

print("\n\n")