import os
import time

# Funções
def verificarStatus(idade, conhecimento):

  if(conhecimento.lower() == "sim"):
    if(idade >= 18): return "APROVADO PARA O ESTÁGIO"
    else: return "APROVADO PARA A ESCOLA DE PROGRAMAÇÃO"

  elif(conhecimento.lower() == "nao"):
    if(idade >= 18): return "NÃO APROVADO PARA O ESTÁGIO"
    else: return "NÃO APROVADO PARA A ESCOLA DE PROGRAMAÇÃO"

  else: return "ERRO NOS DADOS INFORMADOS, TENTE NOVAMENTE"


# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")

def aguarde(tempo): time.sleep(tempo)

def animar(frase):
  tempo = 0.3
  limpa()
  print(frase, end="", flush=True)
  aguarde(tempo)
  print(".", end="", flush=True)
  aguarde(tempo)
  print(".", end="", flush=True)
  aguarde(tempo)
  print(".", end="", flush=True)
  aguarde(tempo)
  limpa()