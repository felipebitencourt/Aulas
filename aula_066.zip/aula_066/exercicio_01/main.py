from funcoes import *

limpa()

nome = input("- Digite o seu nome: ")
idade = int(input("- Digite sua idade: "))
conhecimento = input("- Você tem conhecimentos em programação? ")

animar("A analisar")

print("=== Ficha de Candidatura ===\n")
print(f"Nome: ( {nome} )")
print(f"Idade: ( {idade} )")
print(f"Status da candidatura: ( {verificarStatus(idade, conhecimento)} )")



print("\n\n")