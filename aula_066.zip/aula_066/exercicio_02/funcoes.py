import os
import time
import math

# Funções
def calcTriangulo(base, altura):
  resultado = (base * altura) / 2
  return f"--- A área do triângulo é de ({resultado:.1f}) ---"

def calcRetangulo(base, altura):
  resultado = base * altura
  return f"--- A área do retângulo é de ({resultado:.1f}) ---"

def calcCirculo(raio):
  resultado = math.pi * raio ** 2
  return f"--- A área do círculo é de ({resultado:.1f}) ---"

# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")

def aguarde(tempo): time.sleep(tempo)

def animar(frase):
  tempo = 0.3
  limpa()
  print(frase, end="", flush=True)
  aguarde(tempo)
  print(".", end="", flush=True)
  aguarde(tempo)
  print(".", end="", flush=True)
  aguarde(tempo)
  print(".", end="", flush=True)
  aguarde(tempo)
  limpa()