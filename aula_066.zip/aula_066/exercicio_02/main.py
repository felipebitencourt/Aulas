from funcoes import *

limpa()

print("===== Cálculo de Áreas com Funções =====\n")
print("--- Escolha uma opção ---\n")
print("(t) para triângulos.")
print("(r) para retângulos.")
print("(c) para círculo.\n")

opcao = input("Opção: ")

animar("A analisar")

if(opcao.lower() == "t"):
  base = float(input("- Digita a base: "))
  altura = float(input("- Digita a altura: "))
  resultado = calcTriangulo(base, altura)

elif(opcao.lower() == "r"):
  base = float(input("- Digita a base: "))
  altura = float(input("- Digita a altura: "))
  resultado = calcRetangulo(base, altura)

elif(opcao.lower() == "c"):
  raio = float(input("- Digita o raio: "))
  resultado = calcCirculo(raio)

else: resultado = "--- OPÇÃO INVÁLIDA ---"

animar("A analisar")

print("===== Cálculo de Áreas com Funções =====\n")
print(resultado)


print("\n\n")