from funcoes import *

limpa()


numero = 1
while(numero <= 5):
  print(numero)
  numero += 1


print("\n\n")