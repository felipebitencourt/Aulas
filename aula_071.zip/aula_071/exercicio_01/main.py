from funcoes import *
import globais

limpa()


while(True):
  limpa()
  print("=== MULTIBANCO ===\n")
  print(f"Bem-vindo(a) {globais.nome}")
  print(f"Saldo atual: ( {globais.saldo:.2f} € )\n")

  exibirMenu()

  opcao = int(input("- Opção: "))

  limpa()

  if(opcao == 1): depositar()
  elif(opcao == 2): levantar()
  elif(opcao == 0): 
    animar2("A sair")
    break
  else:
    print("--- OPÇÃO INVÁLIDA ---")

  aguarde(3)


print("\n\n")