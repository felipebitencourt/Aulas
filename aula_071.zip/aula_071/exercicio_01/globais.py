# Variáveis Globais
saldo = 100.00
nome = "Fabrício"