import os
import time
import globais

# Funções
def exibirMenu():
  print("1 - Depositar.")
  print("2 - Levantar.\n")
  print("0 - Sair.\n")

def depositar():
  valor = float(input("- Digite o valor que será depositado: "))
  print()
  if(valor > 0):
    print("--- SUCESSO! ---\n")
    globais.saldo += valor
  else: print("--- VALOR INVÁLIDO ---\n")
  print(f"Novo saldo: ( {globais.saldo:.2f} € )\n")

def levantar():
  valor = float(input("- Digite o valor que será levantado: "))
  print()
  if(valor > 0 and valor <= globais.saldo):
    print("--- SUCESSO! ---\n")
    globais.saldo -= valor
  else: print("--- VALOR INVÁLIDO ---\n")
  print(f"Novo Saldo: ( {globais.saldo:.2f} € )\n")
























# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")

def aguarde(tempo): time.sleep(tempo)

def animar(frase):
  tempo = 0.1
  limpa()

  print(frase, end="", flush=True)
  for loop in range(10):
    print(".", end="", flush=True)
    aguarde(tempo)

  limpa()

def animar2(frase):
  tempo = 0.2
  limpa()
  frase += "..."

  for letra in frase:
    print(letra, end="", flush=True)
    aguarde(tempo)

  limpa()