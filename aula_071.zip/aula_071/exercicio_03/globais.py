# Variáveis Globais
saldo = 1000.00
nome = "Fabrício"
historico = ""