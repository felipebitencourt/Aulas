# Variáveis Globais
pets = []