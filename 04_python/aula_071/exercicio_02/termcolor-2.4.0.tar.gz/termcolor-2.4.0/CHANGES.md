## 2.0.0 and newer

See GitHub Releases:

- https://github.com/termcolor/termcolor/releases

## 1.1.0 (13.01.2011)

- Added cprint function.

## 1.0.1 (13.01.2011)

- Updated README.rst.

## 1.0.0 (13.01.2011)

- Changed license to MIT.
- Updated copyright.
- Refactored source code.

## 0.2 (07.09.2010)

- Added support of Python 3.x.

## 0.1.2 (04.06.2009)

- Fixed bold characters. (Thanks Tibor Fekete)

## 0.1.1 (05.03.2009)

- Some refactoring.
- Updated copyright.
- Fixed reset colors.
- Updated documentation.

## 0.1 (09.06.2008)

- Initial release.
