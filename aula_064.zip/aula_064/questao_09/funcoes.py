import os

# Funções
def calcSalario():
  salario = float(input("- Digite o salário atual: "))
  reajuste = float(input("- Digite o reajuste em %: "))
  novo_salario = salario * (1 + reajuste/100)
  return novo_salario



# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")