from funcoes import *

limpa()

print(f"\nO novo salário será de ( {calcSalario():.2f} € )")

print("\n\n")