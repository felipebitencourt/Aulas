from funcoes import *

limpa()

calcAreaRect()

print("\n\n")