import os

# Funções
def calcAreaRect():
  base = float(input("- Digite a base do retângulo: "))
  altura = float(input("- Digite a altura do retângulo: "))
  area = base * altura
  print(f"\nÁrea = ({area:.1f})")



# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")