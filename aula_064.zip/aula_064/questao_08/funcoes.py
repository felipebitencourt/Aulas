import os

# Funções
def calcVotos(total, brancos, nulos, validos):
  percentagem_brancos = (brancos / total) * 100
  percentagem_nulos = (nulos / total) * 100
  percentagem_validos = (validos / total) * 100
  print()
  print(f"Percentagem de votos em branco: ( {percentagem_brancos:.1f} % )")
  print(f"Percentagem de votos nulos: ( {percentagem_nulos:.1f} % )")
  print(f"Percentagem de votos válidos: ( {percentagem_validos:.1f} % )")



# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")