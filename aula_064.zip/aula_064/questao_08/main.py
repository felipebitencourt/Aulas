from funcoes import *

limpa()

total = int(input("- Digite o total de eleitores: "))
brancos = int(input("- Digite o total de votos em branco: "))
nulos = int(input("- Digite o total de votos nulos: "))
validos = int(input("- Digite o total de votos válidos: "))

calcVotos(total, brancos, nulos, validos)

print("\n\n")