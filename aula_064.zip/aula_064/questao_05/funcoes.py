import os

# Funções
def calcAntecessor():
  numero = int(input("- Digite um número inteiro: "))
  antecessor = numero - 1
  print()
  print(f"O antecessor de ({numero}) é ({antecessor}).")



# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")