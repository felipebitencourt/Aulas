from funcoes import *

limpa()
calcAntecessor()

print("\n\n")