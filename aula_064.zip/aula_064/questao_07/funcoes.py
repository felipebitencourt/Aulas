import os

# Funções
def calcTotalDeDias(anos, meses, dias):
  total_dias = (anos * 365) + (meses * 30) + dias
  print(f"\nTotal de dias vividos: ({total_dias})")



# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")