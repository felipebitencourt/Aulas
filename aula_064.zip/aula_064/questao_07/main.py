from funcoes import *

limpa()

anos = int(input("- Digite o total de anos de vida: "))
meses = int(input("- Digite o total de meses de vida: "))
dias = int(input("- Digite o total de dias de vida: "))

calcTotalDeDias(anos, meses, dias)

print("\n\n")