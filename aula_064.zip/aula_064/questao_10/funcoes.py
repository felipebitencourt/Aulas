import os

# Funções
def calcValorCarro():
  valor_fabrica = float(input("- Digite o valor de fabrica do carro: "))
  valor_final = valor_fabrica * 1.73
  return valor_final



# Funções Especiais
def limpa():
  if(os.name == "nt"): os.system("cls")
  else: os.system("clear")