from funcoes import *

limpa()

print(f"\nO valor final do carro será de ( {calcValorCarro()} € )")

print("\n\n")